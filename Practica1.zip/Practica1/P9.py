# Definir la lista original
lista_original = ['Di', 'buen', 'día', 'a', 'papa']

# Invertir la lista utilizando rebanado
lista_invertida = lista_original[::-1]

# Mostrar la lista invertida
print(lista_invertida)