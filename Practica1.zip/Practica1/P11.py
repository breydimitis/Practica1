# Definir la lista original
lista_original = [1, 1, 2, 3, 4, 4, 5, 1]

# Eliminar duplicados convirtiendo la lista en un conjunto y luego de nuevo en lista
lista_procesada = list(set(lista_original))

# Mostrar la lista procesada
print(lista_procesada)
