# Solicitar el nombre del usuario 
nombre_usuario = input("Ingrese su nombre de usuario: ")
# Mostrar 
print("¡Hola<>!"+nombre_usuario)