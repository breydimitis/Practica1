n = int(input("Hasta que numero quiere que se sumen los enteros?" ))

suma = (n*(n+1))/2

print("La suma es: "+str(suma))